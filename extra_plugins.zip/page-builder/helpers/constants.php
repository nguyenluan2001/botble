<?php

if (!defined('PAGE_BUILDER_MODULE_SCREEN_NAME')) {
    define('PAGE_BUILDER_MODULE_SCREEN_NAME', 'page_builder');
}