# Overview
This is a plugin for Botble CMS so you have to purchase Botble CMS first to use this plugin. 
Purchase it here: [https://codecanyon.net/item/botble-cms-php-platform-based-on-laravel-framework/16928182](https://1.envato.market/LWRBY)

# Installation
- Download and copy source code into `/platform/plugins/page-builder`.
- Go to Admin -> Plugins or run command `php artisan cms:plugin:activate page-builder` to activate this plugin.

# Screenshots

![Screenshot](https://raw.githubusercontent.com/botble/page-builder/master/public/images/screenshot-1.png)

![Screenshot](https://raw.githubusercontent.com/botble/page-builder/master/public/images/screenshot-2.png)

# Contact us
- Website: [https://botble.com](https://botble.com)
- Email: [contact@botble.com](mailto:contact@botble.com)
