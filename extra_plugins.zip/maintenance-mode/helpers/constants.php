<?php

if (!defined('MAINTENANCE_MODE_MODULE_SCREEN_NAME')) {
    define('MAINTENANCE_MODE_MODULE_SCREEN_NAME', 'maintenance_mode');
}