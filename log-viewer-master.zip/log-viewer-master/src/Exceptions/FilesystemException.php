<?php

namespace Botble\LogViewer\Exceptions;

class FilesystemException extends LogViewerException
{
}
