<?php

namespace Botble\LogViewer\Exceptions;

class LogNotFoundException extends LogViewerException
{
}
