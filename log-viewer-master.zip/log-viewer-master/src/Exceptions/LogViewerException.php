<?php

namespace Botble\LogViewer\Exceptions;

use Exception;

class LogViewerException extends Exception
{
}
