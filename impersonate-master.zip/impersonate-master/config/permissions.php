<?php

return [
    [
        'name'        => 'Impersonate',
        'flag'        => 'users.impersonate',
        'parent_flag' => 'users.index',
    ],
];