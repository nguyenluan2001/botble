<?php

return [
    'leave_impersonation' => 'Leave impersonation',
    'login_as_this_user'  => 'Login as this user',
];
